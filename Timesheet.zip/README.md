
  # GrangerPR Timesheet UI Flow

  This is a code bundle for GrangerPR Timesheet UI Flow. The original project is available at https://www.figma.com/design/67DfU7Gj1hDCufNigeiUHk/GrangerPR-Timesheet-UI-Flow.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  